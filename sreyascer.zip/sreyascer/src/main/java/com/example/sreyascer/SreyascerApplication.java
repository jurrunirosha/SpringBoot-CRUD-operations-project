package com.example.sreyascer;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SreyascerApplication {

	public static void main(String[] args) {
		SpringApplication.run(SreyascerApplication.class, args);
	}

}
