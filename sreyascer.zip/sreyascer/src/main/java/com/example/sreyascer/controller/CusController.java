package com.example.sreyascer.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.sreyascer.entity.Customer;
import com.example.sreyascer.service.CustomerService;

//controller class

@RestController

public class CusController {
	
	@Autowired
	public CustomerService cser;
	
	@PostMapping("/addcus")
	public Customer regCustomer(@RequestBody Customer cus) {
		return cser.addCustomer(cus);
	}
	
	@GetMapping("/getcus")
	public List<Customer> getCus() {
		return cser.getCustomer();
	}
	
	@DeleteMapping("/deletecus/{id}")
	public void deleteCus(@PathVariable Long id) {
		cser.deleteCustomer(id);
	}
	
	@PutMapping("/updatecus")
	public Customer updateCus(@RequestBody Customer cus) {
		return cser.updateCustomer(cus);
	}
	

}
