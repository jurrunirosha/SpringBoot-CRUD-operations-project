package com.example.sreyascer.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.sreyascer.entity.Customer;

public interface CustRepo extends JpaRepository<Customer,Long>{

}
