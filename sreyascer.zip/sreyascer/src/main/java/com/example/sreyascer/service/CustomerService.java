package com.example.sreyascer.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.sreyascer.entity.Customer;
import com.example.sreyascer.repository.CustRepo;

//Service class-->CURD operations
//postman->controller-->service-->repository
@Service
public class CustomerService {
	
	@Autowired
	public CustRepo erepo;
	
	
	//post data(inserting the data into table)
	
	public Customer addCustomer(Customer cus) {
		return erepo.save(cus);
		
	}
	
	//get the data
	public List<Customer> getCustomer() {
		return erepo.findAll();
	}
	
	//delete data
	public void deleteCustomer(long id) {
		erepo.deleteById(id);
	}
	
	
	//update data
	//update customer set cname="srujana" where cid=102
	public Customer updateCustomer(Customer cus) {
		Long cid=cus.getCid();
		//getCid(user input in postman)
		//findbyid(table data in database)
		Customer cus1=erepo.findById(cid).get();
		cus1.setCemail(cus.getCemail());
		cus1.setCname(cus.getCname());
		cus1.setCphone(cus.getCphone());
		return erepo.save(cus1);
		
				
				
	}
	
	
	
	
	
	
}
