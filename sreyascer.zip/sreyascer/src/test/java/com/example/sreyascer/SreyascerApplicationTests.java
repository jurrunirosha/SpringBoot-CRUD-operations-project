package com.example.sreyascer;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SreyascerApplicationTests {

	@Test
	void contextLoads() {
	}

}
